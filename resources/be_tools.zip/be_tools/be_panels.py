import bpy
from bpy.types import Menu
from . be_ops import *


class PieMenu(Menu):
    bl_label = ""
    def __init__(self, name):
        bl_label = str(name)
        self.label = bl_label
        self.pie_menu = self.layout.menu_pie()

    def draw(self, context):
        pass


class VertMenu(PieMenu):
    def __init__(self):
        PieMenu.__init__(self, "Vertex")

    def draw(self, context):

        self.pie_menu.operator("mesh.merge", text = "Merge Center", icon = "STICKY_UVS_VERT").type = 'CENTER'
        chamfer = self.pie_menu.operator("mesh.bevel", text = "Chamfer Vertices", icon = "PIVOT_CURSOR") # .vertex_only = True
        chamfer.vertex_only = True

        self.pie_menu.operator("mesh.delete", text = "Delete Vertices", icon = "X").type = 'VERT'

        try:
            self.pie_menu.operator("mesh.merge", text = "Merge Last", icon = "TRACKING_FORWARDS_SINGLE").type = 'LAST'
        except TypeError:
            pass
        try:
            self.pie_menu.operator("mesh.merge", text = "Merge First", icon = "TRACKING_BACKWARDS_SINGLE").type = 'FIRST'
        except TypeError:
            pass

        self.pie_menu.operator("mesh.remove_doubles", text = "Merge Distance", icon = "AUTOMERGE_OFF")
        self.pie_menu.operator("mesh.knife_tool", text = "Knife Tool", icon = "RESTRICT_SELECT_ON")
        self.pie_menu.operator("mesh.vertices_smooth", text = "Smooth Vertices", icon = "SPHERECURVE")


class EdgeMenu(PieMenu):
    def __init__(self):
        PieMenu.__init__(self, "Edge")

    def draw(self, context):
        self.pie_menu.operator("mesh.loopcut_slide", text = "Loop Cut", icon = "MOD_LATTICE")
        self.pie_menu.operator("transform.edge_crease", text = "Crease", icon = "MOD_WIREFRAME")
        self.pie_menu.operator("mesh.dissolve_edges", text = "Dissolve Edges", icon = "X")
        self.pie_menu.operator("mesh.bridge_edge_loops", text = "Bridge", icon = "TRACKING_FORWARDS_SINGLE")
        bevel = self.pie_menu.operator("mesh.bevel", text = "Bevel", icon = "MOD_BEVEL") # .vertex_only = False
        bevel.vertex_only = False
        self.pie_menu.operator("mesh.extrude_edges_move", text = "Extrude", icon = "ORIENTATION_NORMAL")
        self.pie_menu.operator("mesh.knife_tool", text = "Knife Tool", icon = "RESTRICT_SELECT_ON")
        self.pie_menu.operator("transform.edge_slide", text = "Edge Slide", icon = "MOD_SIMPLIFY")


class FaceMenu(PieMenu):
    def __init__(self):
        PieMenu.__init__(self, "Face")

    def draw(self, context):
        self.pie_menu.operator("mesh.extrude_region_shrink_fatten", text = "Extrude by Normals", icon = "NORMALS_FACE")
        self.pie_menu.operator("mesh.faces_shade_smooth", text = "Shade Smooth", icon = "SPHERECURVE")
        self.pie_menu.operator("mesh.delete", text = "Delete Faces", icon = "X").type = 'FACE'
        self.pie_menu.operator("mesh.smart_extract", text = "Smart Extract", icon = "PIVOT_CURSOR")
        self.pie_menu.operator("mesh.inset", text = "Inset Faces", icon = "OBJECT_DATA")
        self.pie_menu.operator("mesh.flip_normals", text = "Flip Normals", icon = "UV_SYNC_SELECT")
        self.pie_menu.operator("mesh.knife_tool", text = "Knife Tool",  icon = "RESTRICT_SELECT_ON")
        self.pie_menu.operator("mesh.faces_shade_flat", text = "Shade Flat", icon = "LINCURVE")


class MeshMenu(PieMenu):
    def __init__(self):
        PieMenu.__init__(self, "Mesh")

    def draw(self, context):
        self.pie_menu.operator("mesh.separate", text = "Split by Loose Parts", icon = "MOD_EXPLODE").type = 'LOOSE'
        self.pie_menu.operator("object.shade_flat", text = "Flat Shade", icon = "LINCURVE")
        self.pie_menu.operator("mesh.simple_edit_pivot", text = "Edit Pivot", icon = "OBJECT_ORIGIN")
        freeze_transforms = self.pie_menu.operator("object.transform_apply", text = "Apply All Transforms", icon = "EMPTY_AXIS")
        freeze_transforms.location = True
        freeze_transforms.rotation = True
        freeze_transforms.scale = True
        apply_transform_delta = self.pie_menu.operator("object.transforms_to_deltas", text = "Apply Delta Transforms", icon = "ORIENTATION_GLOBAL").mode = 'ALL'
        self.pie_menu.operator("object.shade_smooth", text = "Smooth Shade", icon = "SPHERECURVE")
        self.pie_menu.operator("wm.call_menu_pie", text = "Mirror Object", icon = "RIGHTARROW_THIN").name = "MirrorMenu"
        self.pie_menu.operator("mesh.quick_pivot", text = "Quick Pivot", icon = "EMPTY_ARROWS")


class MirrorMenu(PieMenu):
    def __init__(self):
        PieMenu.__init__(self, "Mirror")

    def draw(self, context):
        mirror_x = self.pie_menu.operator("mesh.smart_mirror_x", text = "Mirror X", icon = "TRIA_LEFT")
        mirror_y = self.pie_menu.operator("mesh.smart_mirror_y", text = "Mirror Y", icon = "TRIA_RIGHT")
        self.pie_menu.operator("wm.call_menu_pie", text = "Back", icon = "FILE_PARENT").name = "MeshMenu"
        mirror_z = self.pie_menu.operator("mesh.smart_mirror_z", text = "Mirror Z", icon = "TRIA_UP")

class VIEW3D_OT_PIE_CALL(bpy.types.Operator):
    bl_idname = "view3d.b_modeling_hot_box"
    bl_label = "BE Tools - Modeling Hot Box"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        self.get_menu_context()
        return {'FINISHED'}

    def get_menu_context(self):
        try:
            context_mode = bpy.context.object.mode
            selection_mode = tuple(bpy.context.scene.tool_settings.mesh_select_mode)

            if context_mode == "OBJECT":
                bpy.ops.wm.call_menu_pie(name="MeshMenu")
                return
            else:
                if selection_modes[selection_mode] == "VERTEX":
                    bpy.ops.wm.call_menu_pie(name="VertMenu")
                elif selection_modes[selection_mode] == "EDGE":
                    bpy.ops.wm.call_menu_pie(name="EdgeMenu")
                else:
                    bpy.ops.wm.call_menu_pie(name="FaceMenu")
        except AttributeError:
            print("No objects currently in the scene")
            pass
