

# TODO wrap the merge vert commands into a new operator