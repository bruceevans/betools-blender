selection_modes = {
    (True, False, False)    : "VERTEX",
    (False, True, False)    : "EDGE",
    (False, False, True)    : "FACE"
}

mirror_modes = {
    "X" : (True, False, False),
    "Y" : (False, True, False),
    "Z" : (False, False, True)
}

import bpy
import bmesh
from mathutils import Vector
import math


class SmartExtract(bpy.types.Operator):

    bl_idname = "mesh.smart_extract"
    bl_label = "Smart Extract"
    bl_description = "Extract selected faces into a new mesh"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):

        # bpy.ops.object.editmode_toggle()
        bpy.ops.object.mode_set(mode = 'OBJECT')
        bpy.ops.object.duplicate()
        bpy.ops.object.mode_set(mode = 'EDIT')
        obj = bpy.context.selected_objects[0]
        bpy.ops.mesh.select_all(action='INVERT')
        bpy.ops.mesh.delete(type='FACE')
        bpy.data.objects[obj.name].select_set(True)
        bpy.ops.object.mode_set(mode = 'OBJECT')
        bpy.ops.mesh.be_center_pivot()
        return {'FINISHED'}

    @classmethod
    def poll(cls, context):
        return context.object is not None


class SmartMirror(bpy.types.Operator):
    bl_label = ""
    bl_description = ""
    bl_idname = "mesh.smart_mirror"
    bl_options = {'REGISTER', 'UNDO'}

    def __init__(self, direction, name):
        bl_label = str(name)
        bl_description = "Global mirror operation in the chosen axis"
        self.label = bl_label
        self.mirror_direction = direction

    def execute(self, context):
        bpy.ops.object.mode_set(mode = 'OBJECT')
        bpy.ops.object.duplicate()
        bpy.ops.transform.mirror(orient_type='GLOBAL', constraint_axis=(self.mirror_direction), use_proportional_edit=False, proportional_edit_falloff='SMOOTH', proportional_size=1, use_proportional_connected=False, use_proportional_projected=False)
        return {'FINISHED'}

    @classmethod
    def poll(cls, context):
        return context.object is not None


class SmartMirrorX(SmartMirror):
    bl_idname = "mesh.smart_mirror_x"
    def __init__(self):
        SmartMirror.__init__(self, mirror_modes["X"], "Smart Mirror X")


class SmartMirrorY(SmartMirror):
    bl_idname = "mesh.smart_mirror_y"
    def __init__(self):
        SmartMirror.__init__(self, mirror_modes["Y"], "Smart Mirror Y")


class SmartMirrorZ(SmartMirror):
    bl_idname = "mesh.smart_mirror_z"
    def __init__(self):
        SmartMirror.__init__(self, mirror_modes["Z"], "Smart Mirror Z")


class SeamHardEdge(bpy.types.Operator):
    bl_label = "Hard Edge Seams"
    bl_description = "Create seams along hard edges based on Auto-Smooth angle."
    bl_idname = "mesh.seams_from_hard_edge"
    bl_options = {'REGISTER', 'UNDO'}

    def __init__(self):

        self.current_selection = bpy.context.object.data

    def execute(self, context):

        # turn on auto smooth
        if not self.current_selection.use_auto_smooth:
            self.current_selection.use_auto_smooth = 1

        # Make sure in edit mode
        bpy.ops.object.mode_set(mode = 'EDIT')
        smooth_angle = bpy.context.object.data.auto_smooth_angle

        # deselect all components
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.mesh.edges_select_sharp(sharpness=smooth_angle)
        bpy.ops.mesh.mark_seam(clear=False)
        bpy.context.active_object.select_set(False)

        return {'FINISHED'}

    @classmethod
    def poll(cls, context):
        return context.object is not None


class BEAutoSmooth(bpy.types.Operator):
    bl_label = "Automatically smooth hard edges"
    bl_description = "Smooth hard edges based on an angle value"
    bl_idname = "mesh.be_auto_smooth"
    bl_options = {'REGISTER', 'UNDO'}

    def __init__(self, angle):
        self.angle = angle

    def execute(self, context):
        try:
            bpy.ops.object.mode_set(mode = 'OBJECT')
            bpy.ops.object.shade_smooth()  #TODO try not to use operators
            bpy.context.object.data.use_auto_smooth = True
            bpy.context.object.data.auto_smooth_angle = self.angle
        except TypeError:
            # TODO message
            pass
        return {'FINISHED'}

    @classmethod
    def poll(cls, context):
        return context.object is not None


class BEAutoSmooth30(BEAutoSmooth):
    bl_idname = "mesh.be_auto_smooth_30"
    def __init__(self):
        BEAutoSmooth.__init__(self, 0.523599)


class BEAutoSmooth45(BEAutoSmooth):
    bl_idname = "mesh.be_auto_smooth_45"
    def __init__(self):
        BEAutoSmooth.__init__(self, 0.785398)


class BEAutoSmooth60(BEAutoSmooth):
    bl_idname = "mesh.be_auto_smooth_60"
    def __init__(self):
        BEAutoSmooth.__init__(self, 1.0472)


class DivideLattice(bpy.types.Operator):
    bl_label = "Lattice"
    bl_description = "Create a lattice deformer"
    bl_idname = "mesh.be_lattice"
    bl_options = {'REGISTER', 'UNDO'}

    def __init__(self, divisions):
        self.divisions = divisions
        self.current_selection = bpy.context.object.data

    def execute(self, context):
        try:

            #  TODO move pivots
            bpy.ops.mesh.be_lattice()

            if self.divisions == 2:
                bpy.context.object.data.points_u = 3
                bpy.context.object.data.points_v = 3
                bpy.context.object.data.points_w = 3
            elif self.divisions == 3:
                bpy.context.object.data.points_u = 4
                bpy.context.object.data.points_v = 4
                bpy.context.object.data.points_w = 4
            elif self.divisions == 4:
                bpy.context.object.data.points_u = 5
                bpy.context.object.data.points_v = 5
                bpy.context.object.data.points_w = 5
            # Add undo state
            bpy.ops.object.mode_set(mode = 'OBJECT')
        except TypeError:
            pass
        return {'FINISHED'}

    @classmethod
    def poll(cls, context):
        return context.object is not None

class Lattice_2(DivideLattice):
    bl_idname = "mesh.lattice_2"
    def __init__(self):
        DivideLattice.__init__(self, 2)

class Lattice_3(DivideLattice):
    bl_idname = "mesh.lattice_3"
    def __init__(self):
        DivideLattice.__init__(self, 3)

class Lattice_4(DivideLattice):
    bl_idname = "mesh.lattice_4"
    def __init__(self):
        DivideLattice.__init__(self, 4)


class Lattice(bpy.types.Operator):
    bl_idname = "mesh.be_lattice"
    bl_label = "Simple Lattice"
    bl_description = "Quickly create lattices based on the objects bounding box and position"
    bl_options = {'REGISTER', 'UNDO'}

    # save old pivot (move cursor to pivot location?)
    # center pivot
    # create lattice
    # adjust dimensions
    # move back to old pivot (cursor)

    def lattice_prep(self, context, selection):
        if context.mode == 'OBJECT':
            vertices = selection.data.vertices
            vert_positions = [vertex.co @ selection.matrix_world for vertex in vertices]
            rotation = bpy.data.objects[selection.name].rotation_euler
        elif context.mode == 'EDIT_MESH':
            bmesh = get_bmesh()
            selection_mode = (tuple(bpy.context.scene.tool_settings.mesh.select_mode))
            if selection_mode[0]:
                vertices = get_selected(verts=True, get_item = True)
            elif selection_mode[1]:
                edges = get_selected(edges = True, get_item = True)
                verts = [edge.verts for edge in edges]
                verts = [vert for vert_pair in verts for ver in vert_pair]
                verts = list(set(verts))
            elif selection_mode[2]:
                faces = get_selected(faces = True, get_item = True)
                verts = [face.verts for face in faces]
                verts = [vert for vert_pair in verts for vert in vert_pair]
                verts = list(set(verts))

            vert_positions = [(selection.matrix_world @ vert.co) for vert in verts]

            selection.vertex_groups.new(name = "lattice_group")
            bpy.ops.object.vertex_group_assign()
            rotation = Vector()
            bpy.ops.object.editmode_toggle()
        minimum = Vector()
        maximum = Vector()
        
        for axis in range(3):
            pos_list = [pos[axis] for pos in vert_positions]
            maximum[axis] = max(pos_list)
            minimum[axis] = min(pos_list)
        location = (maximum + minimum) / 2
        dimensions = maximum - minimum
        
        # Get pivot position
        # TODO create the lattice based on pivot so the object doesn't have to be at origin

        # Create the lattice

        bpy.ops.object.add(type='LATTICE', enter_editmode=False, location=(0, 0, 0))
        lattice = bpy.context.active_object
        lattice.data.use_outside = True
        lattice.name = selection.name + ".Lattice"
        lattice.data.interpolation_type_u = 'KEY_LINEAR'
        lattice.data.interpolation_type_v = 'KEY_LINEAR'
        lattice.data.interpolation_type_w = 'KEY_LINEAR'
        lattice.location = location
        lattice.scale = dimensions
        lattice.rotation_euler = rotation
        bpy.context.view_layer.objects.active = selection
        bpy.ops.object.modifier_add(type='LATTICE')
        selection.modifiers["Lattice"].object = lattice
        selection.modifiers["Lattice"].vertex_group = "lattice_group"
        bpy.context.view_layer.objects.active = lattice

        # Deselect object, select lattice and make it active, switch to edit mode

        bpy.data.objects[selection.name].select_set(False)
        bpy.data.objects[lattice.name].select_set(True)
        bpy.ops.object.editmode_toggle()

    def apply_lattice(self, context, lattice):
        if context.mode == 'EDIT_MESH':
            bpy.ops.object.editmode_toggle()
        obj = bpy.data.objects[lattice.name[:-8]]
        bpy.data.objects[lattice.name].select_set(False)
        bpy.data.objects[obj.name].select_set(True)
        bpy.context.view_layer.objects.active = obj
        bpy.ops.object.modifier_apply(apply_as='DATA', modifier="Lattice")
		# Delete vertex group
        vg = obj.vertex_groups.get("lattice_group")
        if vg is not None:
            obj.vertex_groups.remove(vg)
		# Delete lattice
        bpy.data.objects[obj.name].select_set(False)
        bpy.data.objects[lattice.name].select_set(True)
        bpy.ops.object.delete()
        bpy.data.objects[obj.name].select_set(True)
        bpy.ops.object.editmode_toggle()

    def get_lattice(self,context, obj):
        lattice = obj.name + ".Lattice"
        if bpy.data.objects.get(lattice) is None:
            return False
        else:
            bpy.data.objects[obj.name].select_set(False)
            bpy.data.objects[lattice].select_set(True)
            context.view_layer.objects.active = bpy.data.objects[lattice]
            bpy.ops.object.editmode_toggle()
            return True

    def execute(self, context):
        selection = bpy.context.active_object
        if selection.name.endswith(".Lattice"):
            self.apply_lattice(context, selection)
        elif self.get_lattice(context, selection):
            lattice = bpy.context.active_object
        else:
            self.lattice_prep(context, selection)
        return{'FINISHED'}


class CenterPivot(bpy.types.Operator):
    bl_label = "Center Pivot"
    bl_description = "Move the pivot point to the center of the object."
    bl_idname = "mesh.be_center_pivot"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        try:
            bpy.ops.object.origin_set(type='ORIGIN_CENTER_OF_MASS', center='MEDIAN')
        except TypeError:
            pass
        return {'FINISHED'}

    @classmethod
    def poll(cls, context):
        return context.object is not None

class Pivot2Cursor(bpy.types.Operator):
    bl_label = "Pivot to 3D Cursor"
    bl_description = "Move the pivot point to the 3D cursor"
    bl_idname = "mesh.be_pivot2cursor"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        try:
            bpy.ops.object.origin_set(type='ORIGIN_CURSOR', center='MEDIAN')
        except TypeError:
            pass
        return {'FINISHED'}

    @classmethod
    def poll(cls, context):
        return context.object is not None

class SmartBevel(bpy.types.Operator):
    bl_idname = "mesh.be_bevel"
    bl_label = "Smart Bevel"
    bl_description = "Bevel Edges or Chamfer Vertices"
    bl_options = {'REGISTER', 'UNDO'}

    def bevel(self):
        selection_mode = (tuple(bpy.context.scene.tool_settings.mesh_select_mode))
        if selection_mode[0]:
            bpy.ops.mesh.bevel('INVOKE_DEFAULT',vertex_only=True)
        elif selection_mode[1]:
            bpy.ops.mesh.bevel('INVOKE_DEFAULT',vertex_only=False)
        else:
            pass

    def execute(self, context):
        self.bevel()
        return{"FINISHED"}

    @classmethod
    def poll(cls, context):
        return context.object is not None

class ToggleWireFrame(bpy.types.Operator):
    bl_idname = "mesh.be_toggle_wireframe"
    bl_label = "Toggle Wireframe"
    bl_description = "Toggle wireframe mode on and off"
    bl_options = {'REGISTER', 'UNDO'}

    def toggle_wireframe(self, context):
        if context.space_data.overlay.show_wireframes:
            context.space_data.overlay.show_wireframes = False
        else:
            context.space_data.overlay.show_wireframes = True

    def execute(self, context):
        self.toggle_wireframe(context)
        return{'FINISHED'}

# TODO Edit Pivot

# TODO UV STACK
