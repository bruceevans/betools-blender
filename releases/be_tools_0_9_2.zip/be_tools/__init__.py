# ------------------------------------------------------------------------------
# BE Tools by Bruce Evans - brucein3d@gmail.com
# Thank you so much for supporting my work!  Please reach out with feedback,
# and other requests.  I would love to hear them.
# ------------------------------------------------------------------------------

bl_info = {
    "name": "BE Tools",
    "author": "Bruce Evans",
    "version": (1, 0, 0),
    "description": "Context sensitive pie menus for various modeling tasks, mimics Maya's shift + RMB functionality and a shelf like menu for easy access modeling functions",
    "blender": (2, 80, 0),
    "category": "User Interface"
}

import bpy
from . import be_panels
from . be_panels import BEToolsPanel
from . be_panels import PieMenu
from . be_panels import VertMenu
from . be_panels import EdgeMenu
from . be_panels import FaceMenu
from . be_panels import MeshMenu
from . be_panels import MirrorMenu
from . be_panels import VIEW3D_OT_PIE_CALL
from . be_ops import SmartExtract
from . be_ops import SmartMirror
from . be_ops import SmartMirrorX
from . be_ops import SmartMirrorY
from . be_ops import SmartMirrorZ
from . be_ops import BEAutoSmooth
from . be_ops import BEAutoSmooth30
from . be_ops import BEAutoSmooth45
from . be_ops import BEAutoSmooth60
from . be_ops import SeamHardEdge
from . be_ops import DivideLattice
from . be_ops import Lattice
from . be_ops import Lattice_2
from . be_ops import Lattice_3
from . be_ops import Lattice_4
from . be_ops import CenterPivot
from . be_ops import Pivot2Cursor
from . be_ops import SmartBevel
from . be_ops import ToggleWireFrame

addon_keymaps = []

classes = (
    BEToolsPanel,
    PieMenu,
    VertMenu,
    EdgeMenu,
    FaceMenu,
    MeshMenu,
    MirrorMenu,
    SmartExtract,
    SmartMirror,
    SmartMirrorX,
    SmartMirrorY,
    SmartMirrorZ,
    VIEW3D_OT_PIE_CALL,
    BEAutoSmooth,
    BEAutoSmooth30,
    BEAutoSmooth45,
    BEAutoSmooth60,
    SeamHardEdge,
    DivideLattice,
    Lattice,
    Lattice_2,
    Lattice_3,
    Lattice_4,
    CenterPivot,
    Pivot2Cursor,
    SmartBevel,
    ToggleWireFrame
)

def register():
    for c in classes:
        bpy.utils.register_class(c)

    # keymapping
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name="3D View", space_type='VIEW_3D')
    kmi = km.keymap_items.new(VIEW3D_OT_PIE_CALL.bl_idname, 'SPACE', 'PRESS')
    kmi.active = True
    addon_keymaps.append((km, kmi))

    ## ICONS ##

    icons = [
        "AS_30.png",
        "AS_45.png",
        "AS_60.png",
        "BRIDGE.png",
        "CHAMFER.png",
        "EDGE_EXT.png",
        "LATTICE_2.png",
        "LATTICE_3.png",
        "LATTICE_4.png",
        "MERGE_FIRST.png",
        "MERGE_LAST.png",
        "MIRROR_X.png",
        "MIRROR_Y.png",
        "MIRROR_Z.png",
        "VERT_SLIDE.png",
        "WIRE.png",
        "WIRE_SHADED.png"
    ]

    for icon in icons:
        be_panels.register_icon(icon)

def unregister():
    for c in classes:
        bpy.utils.unregister_class(c)

    for km, kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()

if __name__ == "__main__":
    register()
