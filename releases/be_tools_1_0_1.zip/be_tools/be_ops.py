# ------------------------------------------------------------------------------
# BE Tools by Bruce Evans - brucein3d@gmail.com
# Thank you so much for supporting my work!  Please reach out with feedback,
# and other requests.  I would love to hear them.
# ------------------------------------------------------------------------------

selection_modes = {
    (True, False, False)    : "VERTEX",
    (False, True, False)    : "EDGE",
    (False, False, True)    : "FACE"
}

mirror_modes = {
    "X" : (True, False, False),
    "Y" : (False, True, False),
    "Z" : (False, False, True)
}

import bpy
import bmesh
from mathutils import Vector
import math


class SmartExtract(bpy.types.Operator):

    bl_idname = "mesh.smart_extract"
    bl_label = "Smart Extract"
    bl_description = "Extract selected faces into a new mesh.  Must be in FACE mode"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):

        bpy.ops.object.mode_set(mode = 'OBJECT')
        bpy.ops.object.duplicate()
        bpy.ops.object.mode_set(mode = 'EDIT')
        obj = bpy.context.selected_objects[0]
        bpy.ops.mesh.select_all(action ='INVERT')
        bpy.ops.mesh.delete(type='FACE')
        bpy.data.objects[obj.name].select_set(True)
        bpy.ops.object.mode_set(mode = 'OBJECT')
        bpy.ops.mesh.be_center_pivot()
        return {'FINISHED'}

    @classmethod
    def poll(cls, context):
        sm = tuple(bpy.context.tool_settings.mesh_select_mode)
        if sm[2] and context.object is not None:
            return True


class SmartMirror(bpy.types.Operator):
    bl_label = ""
    bl_description = ""
    bl_idname = "mesh.smart_mirror"
    bl_options = {'REGISTER', 'UNDO'}

    def __init__(self, direction, name):
        bl_label = str(name)
        bl_description = "Global mirror operation in the chosen axis"
        self.label = bl_label
        self.mirror_direction = direction

    def execute(self, context):
        bpy.ops.object.mode_set(mode = 'OBJECT')
        bpy.ops.object.duplicate()
        bpy.ops.transform.mirror(orient_type='GLOBAL', constraint_axis=(self.mirror_direction), use_proportional_edit=False, proportional_edit_falloff='SMOOTH', proportional_size=1, use_proportional_connected=False, use_proportional_projected=False)
        return {'FINISHED'}

    @classmethod
    def poll(cls, context):
        return context.object is not None


class SmartMirrorX(SmartMirror):
    bl_idname = "mesh.smart_mirror_x"
    def __init__(self):
        SmartMirror.__init__(self, mirror_modes["X"], "Smart Mirror X")


class SmartMirrorY(SmartMirror):
    bl_idname = "mesh.smart_mirror_y"
    def __init__(self):
        SmartMirror.__init__(self, mirror_modes["Y"], "Smart Mirror Y")


class SmartMirrorZ(SmartMirror):
    bl_idname = "mesh.smart_mirror_z"
    def __init__(self):
        SmartMirror.__init__(self, mirror_modes["Z"], "Smart Mirror Z")


class SeamHardEdge(bpy.types.Operator):
    bl_label = "Hard Edge Seams"
    bl_description = "Create seams along hard edges based on Auto-Smooth angle. Must be in OBJECT or EDGE mode"
    bl_idname = "mesh.seams_from_hard_edge"
    bl_options = {'REGISTER', 'UNDO'}

    def __init__(self):

        self.current_selection = bpy.context.object.data

    def check_edge_mode(self):
        sm = tuple(bpy.context.tool_settings.mesh_select_mode)
        return sm[1]

    def make_seams(self):
        # turn on auto smooth
        if not self.current_selection.use_auto_smooth:
            self.report({'INFO'}, 'Turn on auto smooth')
        else:
            # Make sure in edit mode
            bpy.ops.object.mode_set(mode = 'EDIT')
            smooth_angle = bpy.context.object.data.auto_smooth_angle

            # deselect all components
            bpy.ops.mesh.select_all(action ='DESELECT')
            bpy.ops.mesh.edges_select_sharp(sharpness=smooth_angle)
            bpy.ops.mesh.mark_seam(clear=False)
            bpy.context.active_object.select_set(False)

    def execute(self, context):
        self.make_seams()
        return {'FINISHED'}

    @classmethod
    def poll(cls, context):
        sm = tuple(bpy.context.tool_settings.mesh_select_mode)
        if context.object is not None and sm[1] or sm[1] and bpy.context.active_object.mode == "OBJECT":
            return True


class BEAutoSmooth(bpy.types.Operator):
    bl_label = "Automatically smooth hard edges"
    bl_description = "Smooth hard edges based on an angle value"
    bl_idname = "mesh.be_auto_smooth"
    bl_options = {'REGISTER', 'UNDO'}

    def __init__(self, angle):
        self.angle = angle

    def execute(self, context):
        try:
            bpy.ops.object.mode_set(mode = 'OBJECT')
            bpy.ops.object.shade_smooth()  #TODO try not to use operators
            bpy.context.object.data.use_auto_smooth = True
            bpy.context.object.data.auto_smooth_angle = self.angle
        except TypeError:
            # TODO message
            pass
        return {'FINISHED'}

    @classmethod
    def poll(cls, context):
        return context.object is not None


class BEAutoSmooth30(BEAutoSmooth):
    bl_idname = "mesh.be_auto_smooth_30"
    def __init__(self):
        BEAutoSmooth.__init__(self, 0.523599)


class BEAutoSmooth45(BEAutoSmooth):
    bl_idname = "mesh.be_auto_smooth_45"
    def __init__(self):
        BEAutoSmooth.__init__(self, 0.785398)


class BEAutoSmooth60(BEAutoSmooth):
    bl_idname = "mesh.be_auto_smooth_60"
    def __init__(self):
        BEAutoSmooth.__init__(self, 1.0472)


class DivideLattice(bpy.types.Operator):
    bl_label = "Lattice"
    bl_description = "Create a lattice deformer"
    bl_idname = "mesh.be_lattice"
    bl_options = {'REGISTER', 'UNDO'}

    def __init__(self, divisions):
        self.divisions = divisions
        self.current_selection = bpy.context.object.data

    def execute(self, context):
        try:

            #  TODO move pivots
            bpy.ops.mesh.be_lattice()

            if self.divisions == 2:
                bpy.context.object.data.points_u = 3
                bpy.context.object.data.points_v = 3
                bpy.context.object.data.points_w = 3
            elif self.divisions == 3:
                bpy.context.object.data.points_u = 4
                bpy.context.object.data.points_v = 4
                bpy.context.object.data.points_w = 4
            elif self.divisions == 4:
                bpy.context.object.data.points_u = 5
                bpy.context.object.data.points_v = 5
                bpy.context.object.data.points_w = 5
            # Add undo state
            bpy.ops.object.mode_set(mode = 'OBJECT')
        except TypeError:
            pass
        return {'FINISHED'}

    @classmethod
    def poll(cls, context):
        return context.object is not None

class Lattice_2(DivideLattice):
    bl_idname = "mesh.lattice_2"
    def __init__(self):
        DivideLattice.__init__(self, 2)

class Lattice_3(DivideLattice):
    bl_idname = "mesh.lattice_3"
    def __init__(self):
        DivideLattice.__init__(self, 3)

class Lattice_4(DivideLattice):
    bl_idname = "mesh.lattice_4"
    def __init__(self):
        DivideLattice.__init__(self, 4)


class Lattice(bpy.types.Operator):
    bl_idname = "mesh.be_lattice"
    bl_label = "Simple Lattice"
    bl_description = "Quickly create lattices based on the objects bounding box and position"
    bl_options = {'REGISTER', 'UNDO'}

    # TODO repalce with your bbox code

    def get_bounding_box(self):

        selection = bpy.context.active_object

        if selection.mode == 'EDIT':
            bpy.ops.object.mode_set(mode = 'OBJECT')

        vertices = selection.data.vertices
        vert_positions = [vertex.co @ selection.matrix_world for vertex in vertices]
        self.rotation = bpy.data.objects[selection.name].rotation_euler
        self.location = bpy.data.objects[selection.name].location

        bb_min = Vector()
        bb_max = Vector()

        for axis in range(3):
            pos_list = [pos[axis] for pos in vert_positions]
            bb_max[axis] = max(pos_list)
            bb_min[axis] = min(pos_list)
            
        #  add location offset
        bb_max += self.location
        bb_min += self.location
        bounding_box = [bb_min, bb_max]

        return bounding_box

    def lattice_prep(self, context, selection):

        selection = bpy.context.active_object

        if selection.mode == 'EDIT':
            bpy.ops.object.mode_set(mode = 'OBJECT')

        # backup the original rotation
        # orig_rotation = selection.rotation_euler
        # print("Original rotation is ", orig_rotation)
        # zero out the rotation
        # selection.rotation_euler = (0, 0, 0)

        vertices = selection.data.vertices
        vert_positions = [vertex.co @ selection.matrix_world for vertex in vertices]
        self.obj_location = bpy.data.objects[selection.name].location

        minimum = Vector()
        maximum = Vector()
        
        for axis in range(3):
            pos_list = [pos[axis] for pos in vert_positions]
            maximum[axis] = max(pos_list)
            minimum[axis] = min(pos_list)
        center = (maximum + minimum) / 2
        dimensions = maximum - minimum

        self.lattice_location = self.obj_location + center

        # Create the lattice
        bpy.ops.object.add(type='LATTICE', enter_editmode=False, location=self.lattice_location)
        lattice = bpy.context.active_object
        lattice.data.use_outside = True
        lattice.name = selection.name + ".Lattice"
        lattice.data.interpolation_type_u = 'KEY_LINEAR'
        lattice.data.interpolation_type_v = 'KEY_LINEAR'
        lattice.data.interpolation_type_w = 'KEY_LINEAR'
        lattice.scale = dimensions
        lattice.rotation_euler = selection.rotation_euler
        bpy.context.view_layer.objects.active = selection
        bpy.ops.object.modifier_add(type='LATTICE')
        selection.modifiers["Lattice"].object = lattice
        selection.modifiers["Lattice"].vertex_group = "lattice_group"
        bpy.context.view_layer.objects.active = lattice

        # Apply original rotations TODO

        # print(selection.name)
        # print(lattice.name)

        # Deselect object, select lattice and make it active, switch to edit mode

        bpy.data.objects[selection.name].select_set(False)
        bpy.data.objects[lattice.name].select_set(True)
        bpy.ops.object.editmode_toggle()

    def apply_lattice(self, context, lattice):
        if context.mode == 'EDIT_MESH':
            bpy.ops.object.editmode_toggle()
        obj = bpy.data.objects[lattice.name[:-8]]
        bpy.data.objects[lattice.name].select_set(False)
        bpy.data.objects[obj.name].select_set(True)
        bpy.context.view_layer.objects.active = obj
        bpy.ops.object.modifier_apply(apply_as='DATA', modifier="Lattice")

		# Delete vertex group
        vg = obj.vertex_groups.get("lattice_group")
        if vg is not None:
            obj.vertex_groups.remove(vg)

		# Delete lattice
        bpy.data.objects[obj.name].select_set(False)
        bpy.data.objects[lattice.name].select_set(True)
        bpy.ops.object.delete()
        bpy.data.objects[obj.name].select_set(True)
        bpy.ops.object.editmode_toggle()

    def get_lattice(self,context, obj):
        lattice = obj.name + ".Lattice"
        if bpy.data.objects.get(lattice) is None:
            return False
        else:
            bpy.data.objects[obj.name].select_set(False)
            bpy.data.objects[lattice].select_set(True)
            context.view_layer.objects.active = bpy.data.objects[lattice]
            bpy.ops.object.editmode_toggle()
            return True

    def execute(self, context):
        selection = bpy.context.active_object
        if selection.name.endswith(".Lattice"):
            self.apply_lattice(context, selection)
            selection.location = self.obj_location
        elif self.get_lattice(context, selection):
            lattice = bpy.context.active_object
        else:
            self.lattice_prep(context, selection)
        return{'FINISHED'}

    @classmethod
    def poll(cls, context):
        return context.object is not None


class CenterPivot(bpy.types.Operator):
    bl_label = "Center Pivot"
    bl_description = "Move the pivot point to the center of the object."
    bl_idname = "mesh.be_center_pivot"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        try:
            bpy.ops.object.origin_set(type='ORIGIN_CENTER_OF_MASS', center='MEDIAN')
        except TypeError:
            pass
        return {'FINISHED'}

    @classmethod
    def poll(cls, context):
        return context.object is not None


class Pivot2Cursor(bpy.types.Operator):
    bl_label = "Pivot to 3D Cursor"
    bl_description = "Move the pivot point to the 3D cursor"
    bl_idname = "mesh.be_pivot2cursor"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        try:
            bpy.ops.object.origin_set(type='ORIGIN_CURSOR', center='MEDIAN')
        except TypeError:
            pass
        return {'FINISHED'}

    @classmethod
    def poll(cls, context):
        return context.object is not None


class SmartBevel(bpy.types.Operator):
    bl_idname = "mesh.be_bevel"
    bl_label = "Smart Bevel"
    bl_description = "Bevel Edges or Chamfer Vertices"
    bl_options = {'REGISTER', 'UNDO'}

    def bevel(self):
        selection_mode = (tuple(bpy.context.scene.tool_settings.mesh_select_mode))
        if selection_mode[0]:
            bpy.ops.mesh.bevel('INVOKE_DEFAULT',vertex_only=True)
        elif selection_mode[1]:
            bpy.ops.mesh.bevel('INVOKE_DEFAULT',vertex_only=False)
        else:
            pass

    def execute(self, context):
        self.bevel()
        return{"FINISHED"}

    @classmethod
    def poll(cls, context):
        if context.object is not None and bpy.context.active_object.mode == "EDIT":
            return True


class ToggleWireFrame(bpy.types.Operator):
    bl_idname = "mesh.be_toggle_wireframe"
    bl_label = "Toggle Wireframe"
    bl_description = "Toggle wireframe mode on and off"
    bl_options = {'REGISTER', 'UNDO'}

    def toggle_wireframe(self, context):
        if context.space_data.overlay.show_wireframes:
            context.space_data.overlay.show_wireframes = False
        else:
            context.space_data.overlay.show_wireframes = True

    def execute(self, context):
        self.toggle_wireframe(context)
        return{'FINISHED'}


class UE4CollisionGenerator(bpy.types.Operator):
    # Parent class for collision mesh generation
    bl_idname = "mesh.be_ue4_collision_gen"
    bl_label = "UE4 Collision Generator"
    bl_description = "Create collision geometry for Unreal Engine 4"
    bl_options = {'REGISTER', 'UNDO'}

    def get_bounding_box(self):

        selection = bpy.context.active_object

        if selection.mode == 'EDIT':
            bpy.ops.object.mode_set(mode = 'OBJECT')

        vertices = selection.data.vertices
        vert_positions = [vertex.co @ selection.matrix_world for vertex in vertices]
        self.rotation = bpy.data.objects[selection.name].rotation_euler
        self.obj_location = bpy.data.objects[selection.name].location

        bb_min = Vector()
        bb_max = Vector()

        for axis in range(3):
            pos_list = [pos[axis] for pos in vert_positions]
            bb_max[axis] = max(pos_list)
            bb_min[axis] = min(pos_list)

        self.center = (bb_min + bb_max) / 2.0
        self.location = self.obj_location + self.center
        bounding_box = [bb_min, bb_max]

        return bounding_box

    def generate_bounding_box_verts(self, verts):  # bounding box min and max vector

        vertices = []
        vertex = [0, 0, 0]
        
        vertex = [verts[1].x, verts[1].y, verts[0].z]
        vertices.append(vertex) # min
        vertex = [verts[1].x, verts[0].y, verts[0].z]
        vertices.append(vertex)
        vertex = [verts[0].x, verts[0].y, verts[0].z]
        vertices.append(vertex)
        vertex = [verts[0].x, verts[1].y, verts[0].z]
        vertices.append(vertex)
        
        vertex = [verts[1].x, verts[1].y, verts[1].z]
        vertices.append(vertex)
        vertex = [verts[1].x, verts[0].y, verts[1].z]
        vertices.append(vertex)
        vertex = [verts[0].x, verts[0].y, verts[1].z]
        vertices.append(vertex)
        vertex = [verts[0].x, verts[1].y, verts[1].z]
        vertices.append(vertex)
    
        return vertices

    def generate_bounding_box_faces(self):
    
        faces = [
            (0, 1, 2, 3),
            (4, 7, 6, 5), 
            (0, 4, 5, 1),
            (1, 5, 6, 2),
            (2, 6, 7, 3),
            (4, 0, 3, 7)
            ]
        
        return faces

    def get_name(self, selection, coll_type):  # coll_type = "UBX_", "UCX_", etc.
        name = coll_type + selection.name
        collection = bpy.context.collection
        obj_counter = 0
        for obj in collection.objects:
            if name in obj.name:
                obj_counter += 1
        if obj_counter == 0:
            name = name + "_00"
        elif obj_counter < 10:
            name = name + "_0" + str(obj_counter)
        else:
            name = name + "_" + str(obj_counter)
        return name

    def apply_material(self, obj):

        if len(obj.material_slots) > 0:
            for mat in obj.material_slots:
                bpy.ops.object.material_slot_remove({'object': obj})

        # check if collision material exists
        mat_name = 'mat_collision'
        if self.material_exists(mat_name):
            # apply it
            mat = bpy.data.materials[mat_name]
            obj.data.materials.append(mat)
            bpy.context.object.active_material.blend_method = 'BLEND'
        else:
            mat = bpy.data.materials.new(name = mat_name)
            mat.use_nodes = True
            mat_shader = mat.node_tree.nodes["Principled BSDF"]
            mat_shader.inputs[0].default_value = (0, 1, 1, 1) # cyan color
            mat_shader.inputs[4].default_value = 0 # metallic
            mat_shader.inputs[5].default_value = 0 # specular
            mat_shader.inputs[7].default_value = 1 # roughness
            mat_shader.inputs[10].default_value = 0 # sheen
            mat_shader.inputs[12].default_value = 0 # clearcoat
            mat_shader.inputs[18].default_value = 0.1 # alpha
            obj.data.materials.append(mat)
            bpy.context.object.active_material.blend_method = 'BLEND'
        
    def material_exists(self, material_name):
        for mat in bpy.data.materials:
            if mat.name == material_name:
                return True
        return False

    @classmethod
    def poll(cls, context):
        if context.object is not None and bpy.context.active_object.mode == "OBJECT":
            return True


class UBXCollisionGenerator(UE4CollisionGenerator):
    bl_idname = "mesh.be_ubx_collision"
    bl_label = "UBX Collision Generator"
    bl_description = "Create UBX (Box) collision geometry for Unreal Engine 4"
    bl_options = {'REGISTER', 'UNDO'}

    def fill_bounding_box_mesh(self, name):
        
        collection = bpy.context.collection

        mesh = bpy.data.meshes.new("ubx_collision_mesh")
        bbox = self.get_bounding_box()
        verts = self.generate_bounding_box_verts(bbox)
        faces = self.generate_bounding_box_faces()
        mesh.from_pydata(verts, [], faces)

        obj = bpy.data.objects.new(name, mesh)
        obj.location = self.location - self.center

        collection.objects.link(obj)
        bpy.context.view_layer.objects.active = obj

        self.apply_material(obj)

    def execute(self, context):
        selection = bpy.context.active_object
        self.fill_bounding_box_mesh(self.get_name(selection, "UBX_"))
        return {'FINISHED'}


class UCXBoxCollisionGenerator(UE4CollisionGenerator):
    bl_idname = "mesh.be_ucx_box_collision"
    bl_label = "UBX Collision Generator"
    bl_description = "Create UCX (Convex) collision geometry based on the objects bounding box for Unreal Engine 4"
    bl_options = {'REGISTER', 'UNDO'}

    def fill_bounding_box_mesh(self, name):
        
        collection = bpy.context.collection

        mesh = bpy.data.meshes.new("ucx_box_collision_mesh")
        bbox = self.get_bounding_box()
        verts = self.generate_bounding_box_verts(bbox)
        faces = self.generate_bounding_box_faces()
        mesh.from_pydata(verts, [], faces)

        obj = bpy.data.objects.new(name, mesh)
        obj.location = self.location - self.center

        collection.objects.link(obj)
        bpy.context.view_layer.objects.active = obj

        self.apply_material(obj)

    def execute(self, context):
        selection = bpy.context.active_object
        self.fill_bounding_box_mesh(self.get_name(selection, "UCX_"))
        return {'FINISHED'}


class UCXHullCollisionGenerator(UE4CollisionGenerator):
    bl_idname = "mesh.be_ucx_hull"
    bl_label = "UCX Hull Collision"
    bl_description = "Create convex collision for UE4"
    bl_options = {"REGISTER", "UNDO"}

    def duplicate_mesh(self):
        selection = bpy.context.active_object
        name = self.get_name(selection, "UCX_")
        bpy.ops.object.duplicate()

        selection = bpy.context.active_object

        # apply material
        self.apply_material(selection)

        self.apply_material(selection)
        selection.name = name

    def convex_hull(self):
        # set to edit mode
        bpy.ops.object.mode_set(mode = 'EDIT')
        bpy.ops.mesh.select_all(action='SELECT')
        # create hull
        bpy.ops.mesh.convex_hull()
        bpy.ops.object.mode_set(mode = 'OBJECT')

    def decimate(self):
        bpy.ops.object.modifier_add(type='DECIMATE')

    def execute(self, context):
        self.duplicate_mesh()
        self.convex_hull()
        self.decimate()
        return{'FINISHED'}

class USPCollisionGenerator(UE4CollisionGenerator):
    bl_idname = "mesh.be_usp"
    bl_label = "USP Collision"
    bl_description = "Create sphere collision for UE4"
    bl_options = {"REGISTER", "UNDO"}

    def get_radius(self):
        bbox = self.get_bounding_box()  # generates min and max
        dimensions = []
        x_dim = abs(bbox[1].x - bbox[0].x)
        dimensions.append(x_dim)
        y_dim = abs(bbox[1].y - bbox[0].y)
        dimensions.append(y_dim)
        z_dim = abs(bbox[1].z - bbox[0].z)
        dimensions.append(z_dim)
        sorted_dimensions = sorted(dimensions)
        a = sorted_dimensions[-1] / 2.0
        b = sorted_dimensions[-2] / 2.0
        r = math.sqrt(a*a+b*b)
        return r

    def make_sphere(self, rad, loc, rot):
        selection = bpy.context.active_object
        name = self.get_name(selection, "USP_")
        bpy.ops.mesh.primitive_uv_sphere_add(segments=8, ring_count=8, radius=rad, enter_editmode=False, align='WORLD', location=loc, rotation=rot)
        selection = bpy.context.active_object
        self.apply_material(selection)
        selection.name = name

    def execute(self, context):
        radius = self.get_radius()
        self.make_sphere(radius, self.location, self.rotation)
        return{'FINISHED'}


class UCPCollisionGenerator(UE4CollisionGenerator):
    bl_idname = "mesh.be_ucp"
    bl_label = "UCP Collision"
    bl_description = "Create cylinder collision for UE4"
    bl_options = {"REGISTER", "UNDO"}

    def __init__(self):
        self.bbox = self.get_bounding_box()
        self.dimensions = self.get_dimensions(self.bbox)
        # print("Dimensions are ", self.dimensions)
        self.radius = self.get_radius(self.dimensions)
        self.height = self.get_height(self.dimensions)
        self.axis_rotation = self.get_axis_rotation(self.dimensions)

    def get_dimensions(self, bbox):
        dimensions = []
        x_dim = abs(bbox[1].x - bbox[0].x)
        dimensions.append(x_dim)
        y_dim = abs(bbox[1].y - bbox[0].y)
        dimensions.append(y_dim)
        z_dim = abs(bbox[1].z - bbox[0].z)
        dimensions.append(z_dim)
        return dimensions

    def get_height(self, dimensions):
        h = max(dimensions)
        # print("Height is ", h)
        return h

    def get_radius(self, dimensions):
        sorted_dimensions = sorted(dimensions)
        # print(sorted_dimensions)
        
        # pythag
        a = sorted_dimensions[0] / 2.0
        b = sorted_dimensions[1] / 2.0
        r = math.sqrt(a*a+b*b)
        return r

    def get_axis_rotation(self, dimensions):
        axis = ['X', 'Y', 'Z']
        # print("Largets axis is ", axis[dimensions.index(max(dimensions))])
        rot_axis = axis[dimensions.index(max(dimensions))]

        if rot_axis == 'X':
            return (0, math.radians(90), 0)
        elif rot_axis == 'Y':
            return (math.radians(90), 0, 0)
        else:
            return(0, 0, 0)

    def create_cylinder(self, r, h, loc, rot):
        selection = bpy.context.active_object
        name = self.get_name(selection, "UCP_")
        bpy.ops.mesh.primitive_cylinder_add(vertices=8, radius = r, depth = h, enter_editmode=False, align='WORLD', location=loc, rotation=rot)
        selection = bpy.context.active_object
        selection.rotation_euler = self.axis_rotation
        self.apply_material(selection)
        selection.name = name

    def execute(self, context):
        self.create_cylinder(self.radius, self.height, self.location, self.rotation)
        return{'FINISHED'}
        
# TODO Edit Pivot

# TODO UV STACK
