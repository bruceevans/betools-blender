selection_modes = {
    (True, False, False)    : "VERTEX",
    (False, True, False)    : "EDGE",
    (False, False, True)    : "FACE"
}

mirror_modes = {
    "X" : (True, False, False),
    "Y" : (False, True, False),
    "Z" : (False, False, True)
}

import bpy

class SmartExtract(bpy.types.Operator):

    bl_idname = "mesh.smart_extract"
    bl_label = "Smart Extract"
    bl_description = "Extract selected faces into a new mesh"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):

        bpy.ops.object.editmode_toggle()
        bpy.ops.object.duplicate()
        bpy.ops.object.editmode_toggle()
        obj = bpy.context.selected_objects[0]
        bpy.ops.mesh.select_all(action='INVERT')
        bpy.ops.mesh.delete(type='FACE')
        bpy.data.objects[obj.name].select_set(True)
        bpy.ops.object.editmode_toggle()
        return {'FINISHED'}


class SmartMirror(bpy.types.Operator):
    bl_label = ""
    bl_description = ""
    bl_idname = "mesh.smart_mirror"

    def __init__(self, direction, name):
        bl_label = str(name)
        bl_description = "Global mirror operation in the chosen axis"
        self.label = bl_label
        self.mirror_direction = direction

    def execute(self, context):
        bpy.ops.object.duplicate()
        bpy.ops.transform.mirror(orient_type='GLOBAL', constraint_axis=(self.mirror_direction), use_proportional_edit=False, proportional_edit_falloff='SMOOTH', proportional_size=1, use_proportional_connected=False, use_proportional_projected=False)
        return {'FINISHED'}


class SmartMirrorX(SmartMirror):
    bl_idname = "mesh.smart_mirror_x"
    def __init__(self):
        SmartMirror.__init__(self, mirror_modes["X"], "Smart Mirror X")


class SmartMirrorY(SmartMirror):
    bl_idname = "mesh.smart_mirror_y"
    def __init__(self):
        SmartMirror.__init__(self, mirror_modes["Y"], "Smart Mirror Y")


class SmartMirrorZ(SmartMirror):
    bl_idname = "mesh.smart_mirror_z"
    def __init__(self):
        SmartMirror.__init__(self, mirror_modes["Z"], "Smart Mirror Z")
