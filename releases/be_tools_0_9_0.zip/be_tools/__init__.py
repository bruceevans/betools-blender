# ------------------------------------------------------------------------------
# BE Tools by Bruce Evans - brucein3d@gmail.com
# Thank you so much for supporting my work!  Please reach out with feedback,
# and other requests.  I would love to hear them.
# ------------------------------------------------------------------------------

bl_info = {
    "name": "BE Tools",
    "author": "Bruce Evans",
    "version": (0, 1, 0),
    "description": "Context sensitive pie menus for various modeling tasks, mimics Maya's shift + RMB functionality",
    "blender": (2, 80, 0),
    "category": "User Interface"
}

import bpy
from . be_panels import PieMenu
from . be_panels import VertMenu
from . be_panels import EdgeMenu
from . be_panels import FaceMenu
from . be_panels import MeshMenu
from . be_panels import MirrorMenu
from . be_panels import VIEW3D_OT_PIE_CALL
from . be_ops import SmartExtract
from . be_ops import SmartMirror
from . be_ops import SmartMirrorX
from . be_ops import SmartMirrorY
from . be_ops import SmartMirrorZ


addon_keymaps = []

classes = (
    PieMenu,
    VertMenu,
    EdgeMenu,
    FaceMenu,
    MeshMenu,
    MirrorMenu,
    SmartExtract,
    SmartMirror,
    SmartMirrorX,
    SmartMirrorY,
    SmartMirrorZ,
    VIEW3D_OT_PIE_CALL
)

def register():
    for c in classes:
        bpy.utils.register_class(c)

    # keymapping
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name="3D View", space_type='VIEW_3D')
    kmi = km.keymap_items.new(VIEW3D_OT_PIE_CALL.bl_idname, 'SPACE', 'PRESS')
    kmi.active = True
    addon_keymaps.append((km, kmi))

def unregister():
    for c in classes:
        bpy.utils.unregister_class(c)

    for km, kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()

if __name__ == "__main__":
    register()
