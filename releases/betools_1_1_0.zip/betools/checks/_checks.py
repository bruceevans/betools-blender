
# TODO on anim export, look for 'armature' root